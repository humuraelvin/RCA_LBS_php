<?php

$host = "localhost";

$user = "root";

$password = "";

$dbname = "phpCRUD";

$connection = mysqli_connect($host, $user, $password, $dbname);

?>