<?php

$conn = mysqli_connect('localhost', 'root', '', 'log_db');  

?>